from pathlib import Path
from playwright.sync_api import expect

from flows.flow_initiate_signing_request import initiate_signing_request
from flows.flow_login import login
from pages.page_initiate_signing_request import InitiateSigningRequestPage

def test_add_draft(page) -> None:
    repo_root = Path(__file__).resolve().parents[1]
    pdf_path = repo_root / "data" / "Sequential_Signing_Order_Test.pdf"

    login(page)
    for _ in range(5):
        _, title = initiate_signing_request(
            page=page,
            pdf_path=pdf_path,
            mode="draft"
        )
        flow = InitiateSigningRequestPage(page)
        flow.search_all_contacts_input.click()
        flow.search_all_contacts_input.fill(title)
        flow.search_all_contacts_input.press("Enter")
        expect(page.get_by_text(title)).to_be_visible()